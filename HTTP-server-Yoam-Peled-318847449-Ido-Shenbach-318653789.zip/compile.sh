#!/bin/bash
cd Sources
javac ./Main.java
