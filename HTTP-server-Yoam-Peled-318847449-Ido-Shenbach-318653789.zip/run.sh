#!/bin/bash
cd Sources
java Main
